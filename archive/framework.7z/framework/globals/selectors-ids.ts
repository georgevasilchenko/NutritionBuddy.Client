export class SelectorsIds {
  static CreateCollectionItemSelector = 'fw-create-collection-item';
  static BaseCollectionSelector = 'fw-base-collection';
  static BaseCollectionItemSelector = 'fw-base-collection-item';
  static BaseUpdateSelector = 'fw-base-update';
}

