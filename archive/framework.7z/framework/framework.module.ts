import {NgModule} from '@angular/core';
import {CreateCollectionItemComponent} from '../frontend/components/create-collection-item/create-collection-item.component';
import {BaseUpdateComponent} from '../frontend/components/base-update/base-update.component';
import {BaseCollectionItemComponent} from '../frontend/components/base-collection-item/base-collection-item.component';
import {BaseCollectionComponent} from '../frontend/components/base-collection/base-collection.component';
import {CommonModule} from '@angular/common';
import {RouterModule} from '@angular/router';
import {ObjectUtilityService} from './services/object-utility.service';
import {RoutingService} from './services/routing.service';

@NgModule({
  declarations: [
    BaseCollectionComponent,
    BaseCollectionItemComponent,
    BaseUpdateComponent,
    CreateCollectionItemComponent
  ],
  imports: [
    CommonModule,
    RouterModule
  ],
  exports: [
    CreateCollectionItemComponent
  ],
  providers: [ObjectUtilityService, RoutingService]
})
export class FrameworkModule {

}
