export interface IAppUris {
  getAllUri: string;
  getByIdUri: (id: number) => string;
  createUri: string;
  updateUri: string;
  deleteUri: string;
}
