export class SelectorsIds {
  static HomeSelector = 'nb-home';
  static HeaderSelector = 'nb-header';
  static PageNotFoundSelector = 'nb-404';
  static DashboardTileSelector = 'nb-tile';
  static CollectionTileSelector = 'nb-collection-tile';
  static DashboardPanelSelector = 'nb-dashboard-panel';
  static ActionsPanelSelector = 'nb-actions-panel';
  static ActionButtonSelector = 'nb-action-button';
  static HeaderNavigationButtonSelector = 'nb-header-nav-button';
  static AlertSelector = 'nb-alert';
  static LoginSelector = 'nb-login';
}
