import {NgModule} from '@angular/core';
import {MaterialsModule} from '../materials/materials.module';
import {CommonModule} from '@angular/common';

import {DashboardPanelComponent} from './components/dashboard-panel/dashboard-panel.component';
import {HeaderComponent} from '../frontend/components/header/header.component';
import {HomeComponent} from '../frontend/components/home/home.component';
import {PageNotFoundComponent} from '../frontend/components/page-not-found/page-not-found.component';
import {TileComponent} from '../frontend/components/tile/tile.component';
import {HeaderNavButtonComponent} from '../frontend/components/header-nav-button/header-nav-button.component';
import {RouterModule} from '@angular/router';
import {AlertComponent} from './components/alert/alert.component';
import {LoginComponent} from '../frontend/components/login/login.component';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {AuthModule} from '../auth/auth.module';
import {AlertService} from '../frontend/services/alert.service';
import {LocalStorageService} from '../frontend/services/local-storage.service';
import {LoadingService} from '../frontend/services/loading.service';
import {TempStorageService} from '../frontend/services/temp-storage.service';
import {ComponentFactoryService} from '../frontend/services/component-factory.service';
import {HttpClientService} from '../frontend/services/http-client.service';
import {FrontendModule} from "../frontend/frontend.module";

@NgModule({
  declarations: [
    DashboardPanelComponent,
    HeaderComponent,
    HomeComponent,
    PageNotFoundComponent,
    HeaderNavButtonComponent,
    TileComponent,
    AlertComponent,
    LoginComponent,
  ],
  imports: [
    CommonModule,
    RouterModule,
    FormsModule,
    ReactiveFormsModule,
    MaterialsModule,
    FrontendModule,
    AuthModule
  ],
  exports: [HeaderComponent, AlertComponent],
  providers: [
    ComponentFactoryService,
    LoadingService,
    TempStorageService,
    AlertService,
    LocalStorageService,
    HttpClientService
  ],
  entryComponents: [DashboardPanelComponent]
})
export class CommonAppModule {

}
