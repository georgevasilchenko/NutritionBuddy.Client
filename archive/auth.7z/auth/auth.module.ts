import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {AuthGuardService} from '../frontend/services/auth-guard.service';
import {AuthService} from '../frontend/services/auth.service';
import {HttpModule} from "@angular/http";

@NgModule({
  imports: [
    HttpModule,
    CommonModule
  ],
  declarations: [],
  providers: [
    AuthService,
    AuthGuardService
  ]
})
export class AuthModule {
}
