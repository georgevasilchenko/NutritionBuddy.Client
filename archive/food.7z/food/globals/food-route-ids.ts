export class FoodRouteIds {
  static FoodSearch = 'FoodSearch';
  static FoodEdit = 'FoodEdit';
  static FoodCreate = 'FoodCreate';
  static FoodCollection = 'FoodCollection';
}
