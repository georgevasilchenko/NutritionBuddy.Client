export class FoodSelectorsIds {
  static FoodCollectionSelector = 'f-collection';
  static FoodEditSelector = 'f-edit';
  static FoodServingEditSelector = 'f-food-serving-edit';
  static FoodCollectionItemSelector = 'f-collection-item';
  static FoodSearchCollectionItemSelector = 'f-search-collection-item';
  static FoodAlternativeServingsListSelector = 'f-alt-servings-list';
  static FoodAlternativeServingsListItemSelector = 'f-alt-servings-list-item';
  static FoodSearchSelector = 'f-search';
}
