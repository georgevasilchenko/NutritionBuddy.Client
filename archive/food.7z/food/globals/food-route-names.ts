export class FoodRouteNames {
  static FoodSearch = 'Search Food';
  static FoodEdit = 'Edit Food';
  static FoodCreate = 'Add Food';
  static FoodCollection = 'My Food';
}
