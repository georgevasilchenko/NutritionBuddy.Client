export interface IFoodSearchDetailsRequest {
  id: number;
}

export class FoodSearchDetailsRequest implements IFoodSearchDetailsRequest {
  id: number;

  constructor(id: number) {
    this.id = id;
  }
}
