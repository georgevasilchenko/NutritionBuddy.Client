export interface IFoodSearchRequest {
  value: string;
  maxResults: number;
  pageNumber: number;
}

export class FoodSearchRequest implements IFoodSearchRequest {
  value: string;
  maxResults: number;
  pageNumber: number;

  constructor(spec?: FoodSearchRequest) {
    if (spec) {
      this.value = spec.value;
      this.maxResults = (!spec.maxResults || spec.maxResults === 0) ? 10 : spec.maxResults;
      this.pageNumber = spec.pageNumber ? 0 : spec.pageNumber;
    }
  }
}
