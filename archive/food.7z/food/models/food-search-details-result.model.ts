import {Food, IFood} from './food.model';
import {IServing, Serving} from './serving.model';

export interface IFoodSearchDetailsResult {
  food: IFood;
  servings: IServing[];
}

export class FoodSearchDetailsResult implements IFoodSearchDetailsResult {
  food: Food;
  servings: Serving[];

  constructor(spec?: IFoodSearchDetailsResult) {
    if (spec) {
      this.food = new Food(spec.food);
      if (spec.servings && spec.servings.length > 0) {
        this.servings = [];
        for (const serving of spec.servings) {
          this.servings.push(new Serving(serving));
        }
      }
    }
  }
}
