import {FileImage, IFileImage} from "../../../frontend/models/file-image.model";

export interface IFoodSearchResultItem {
  description: string;
  name: string;
  type: string;
  url: string;
  id: number;
  foodImage: IFileImage;
}

export interface IFoodSearchResult {
  food: IFoodSearchResultItem[];
  maxResults: number;
  pageNumber: number;
  totalResults: number;
}

export class FoodSearchResultItem implements IFoodSearchResultItem {
  description: string;
  name: string;
  type: string;
  url: string;
  id: number;
  foodImage: FileImage;

  get calories(): number {
    const newString = this.description + ' | end';
    return +newString.match(/\d+(?=(kcal \| Fat))/g);
  }

  get carbohydrate(): number {
    const newString = this.description + ' | end';
    return +newString.match(/\d+\.\d+(?=(g \| Protein))/g);
  }

  get protein(): number {
    const newString = this.description + ' | end';
    return +newString.match(/\d+\.\d+(?=(g \| end))/g);
  }

  get fat(): number {
    const newString = this.description + ' | end';
    return +newString.match(/\d{0,4}\.\d{0,4}(?=g \| Carbs)/g);
  }

  constructor(spec?: IFoodSearchResultItem) {
    if (spec) {
      this.description = spec.description;
      this.name = spec.name;
      this.type = spec.type;
      this.url = spec.url;
      this.id = spec.id;
      this.foodImage = new FileImage(spec.foodImage);
    }
  }
}

export class FoodSearchResult implements IFoodSearchResult {
  food: FoodSearchResultItem[];
  maxResults: number;
  pageNumber: number;
  totalResults: number;

  constructor(spec?: IFoodSearchResult) {
    if (spec) {
      if (spec.food && spec.food.length > 0) {
        this.food = [];
        for (const item of spec.food) {
          this.food.push(new FoodSearchResultItem(item));
        }
      }

      this.maxResults = spec.maxResults;
      this.pageNumber = spec.pageNumber;
      this.totalResults = spec.totalResults;
    }
  }
}
