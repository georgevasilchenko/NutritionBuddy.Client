import {Component, Input, OnInit} from '@angular/core';
import {FoodSelectorsIds} from '../../globals/food-selectors-ids';
import {BaseCollectionItemComponent} from '../../../../frontend/components/base-collection-item/base-collection-item.component';
import {LocalStorageService} from '../../../../frontend/services/local-storage.service';
import {Food} from '../../models/food.model';
import {FoodRepositoryService} from '../../services/food-repository.service';
import {FoodSearchDetailsResult} from '../../models/food-search-details-result.model';
import {RoutingService} from '../../../../frontend/services/routing.service';
import {FoodRouteIds} from '../../globals/food-route-ids';

@Component({
  selector: FoodSelectorsIds.FoodSearchCollectionItemSelector,
  templateUrl: './food-search-collection-item.component.html',
  styleUrls: ['../../../../frontend/components/base-collection-item/base-collection-item.component.less']
})
export class FoodSearchCollectionItemComponent extends BaseCollectionItemComponent<Food> implements OnInit {

  @Input() isCreate = false;
  @Input() model;

  constructor(private _localStorageService: LocalStorageService,
              private _foodRepositoryService: FoodRepositoryService,
              private _routingService: RoutingService) {
    super();
  }

  ngOnInit() {

  }

  onClick() {
    if (!this.isCreate) {
      return;
    }

    this._foodRepositoryService.searchFoodDetails(this.model.id)
      .then((response: FoodSearchDetailsResult) => {
        const modelString = JSON.stringify(response);
        this._localStorageService.addValue(this._localStorageService.__SRCH_FOOD_KEY, modelString);
        this._routingService.navigateTo(FoodRouteIds.FoodCreate);
      });
  }
}
