import {Component, Inject, OnDestroy, OnInit} from '@angular/core';
import {BaseComponent} from '../../../../frontend/components/base-component/base.component';
import {ComponentFactoryService} from '../../../../frontend/services/component-factory.service';
import {Food, IFood} from '../../models/food.model';
import {BaseCollectionComponent} from '../../../../frontend/components/base-collection/base-collection.component';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {FoodSearchRequest} from '../../models/food-search-request.model';
import {FoodRepositoryService} from '../../services/food-repository.service';
import {FoodSearchResult} from '../../models/food-search-result.model';
import {FoodSearchCollectionItemComponent} from '../food-search-collection-item/food-search-collection-item.component';

@Component({
  selector: 'app-food-search',
  templateUrl: './food-search.component.html',
  styleUrls: ['./food-search.component.less']
})
export class FoodSearchComponent extends BaseCollectionComponent<Food> implements OnInit, OnDestroy {

  searchModel: FoodSearchRequest;
  searchResult: FoodSearchResult;
  form: FormGroup;

  constructor(@Inject(ComponentFactoryService) protected _factoryService: ComponentFactoryService<Food, BaseComponent<Food>>,
              private _formBuilder: FormBuilder,
              protected _foodRepositoryService: FoodRepositoryService) {
    super(_foodRepositoryService, _factoryService, FoodSearchCollectionItemComponent, undefined);
  }

  ngOnInit() {
    this.model = [];
    this.searchModel = new FoodSearchRequest();
    this.form = this._formBuilder.group({
      value: ['', Validators.required],
      maxResults: [1, [Validators.required, Validators.min(1), Validators.max(50)]],
      pageNumber: [0, Validators.required]
    });
  }

  onSubmit(form: FormGroup) {

    if (!form.dirty) {
      return;
    }

    this.model = [];
    this.destroyChildren();

    this.applyChangedModel(form.value);
    this._foodRepositoryService.searchFood(this.searchModel)
      .then((result: FoodSearchResult) => {
        this.searchResult = result;
        if (this.searchResult.totalResults > 0) {
          for (const resultItem of this.searchResult.food) {
            const newFoodSpec = <IFood>{
              description: resultItem.description,
              name: resultItem.name,
              type: resultItem.type,
              url: resultItem.url,
              id: resultItem.id
            };
            const newFoodItem = new Food(newFoodSpec);
            newFoodItem.foodImage.setDefaultData();
            newFoodItem.serving.setCalories(resultItem.calories);
            newFoodItem.serving.setCarbohydrate(resultItem.carbohydrate);
            newFoodItem.serving.setFat(resultItem.fat);
            newFoodItem.serving.setProtein(resultItem.protein);
            this.model.push(newFoodItem);
          }
        }
        this.onLoadModelComplete();
      });
  }

  applyChangedModel(formValue: any) {
    this.searchModel.value = formValue.value;
    this.searchModel.maxResults = formValue.maxResults;
    this.searchModel.pageNumber = formValue.pageNumber;
  }

  loadModel(): void {

  }

  onLoadModelComplete() {
    this.createComponents(this.model);
  }

  mapResultsToCollection(): void {

  }

  createComponents(model: Food[]): void {
    this.factoryService.setRootViewContainerRef(this.collectionItemsContainer);

    for (const item of model) {
      const newComponent = this.factoryService.addDynamicComponentWithExtendedModel({
        model: item,
        isCreate: true
      }, this.componentType);
      this.components.push(newComponent);
    }
  }

  ngOnDestroy() {
    this.destroyChildren();
  }
}
