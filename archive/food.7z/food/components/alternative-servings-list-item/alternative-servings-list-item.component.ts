import {Component, Input, OnInit} from '@angular/core';
import {Serving} from '../../models/serving.model';
import {BaseComponent} from '../../../../frontend/components/base-component/base.component';
import {FoodSelectorsIds} from '../../globals/food-selectors-ids';

@Component({
  selector: FoodSelectorsIds.FoodAlternativeServingsListItemSelector,
  templateUrl: './alternative-servings-list-item.component.html',
  styleUrls: ['./alternative-servings-list-item.component.less']
})
export class AlternativeServingsListItemComponent extends BaseComponent<Serving> implements OnInit {

  @Input() model: Serving;

  constructor() {
    super();
  }

  ngOnInit() {
  }

}
