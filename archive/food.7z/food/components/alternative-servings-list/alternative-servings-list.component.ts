import {Component, Input, OnInit} from '@angular/core';
import {Serving} from '../../models/serving.model';
import {BaseComponent} from '../../../../frontend/components/base-component/base.component';
import {FoodSelectorsIds} from '../../globals/food-selectors-ids';

@Component({
  selector: FoodSelectorsIds.FoodAlternativeServingsListSelector,
  templateUrl: './alternative-servings-collection.list.html',
  styleUrls: ['./alternative-servings-list.component.less']
})
export class AlternativeServingsListComponent extends BaseComponent<Serving[]> implements OnInit {

  @Input() model: Serving[];

  constructor() {
    super();
  }

  ngOnInit() {
  }

}
