import {Injectable} from '@angular/core';
import {AppUris} from '../../../../globals/app-uris';
import {IAppUris} from '../../../frontend/models/app-uris-contract.model';
import {HttpClientService} from '../../../frontend/services/http-client.service';
import {BaseRepositoryService} from '../../../frontend/services/base-repository.service';
import {Food} from '../models/food.model';
import {FoodSearchRequest} from '../models/food-search-request.model';
import {Response} from '@angular/http';
import {FoodSearchResult, IFoodSearchResult} from '../models/food-search-result.model';
import {FoodSearchDetailsResult, IFoodSearchDetailsResult} from "../models/food-search-details-result.model";

@Injectable()
export class FoodRepositoryService extends BaseRepositoryService<Food> {

  private searchResults: Food[];

  constructor(protected _http: HttpClientService) {
    super(_http, <IAppUris>
      {
        getAllUri: AppUris.FoodGetAll,
        getByIdUri: AppUris.FoodGetById,
        createUri: AppUris.FoodCreate,
        updateUri: AppUris.FoodUpdate,
        deleteUri: AppUris.FoodDelete,
      });
    this.searchResults = [];
  }

  searchFood(searchModel: FoodSearchRequest): Promise<FoodSearchResult> {
    return this._http.get(AppUris.SearchFood(searchModel))
      .then((response: Response) => {
        return new FoodSearchResult(<IFoodSearchResult>response.json());
      })
      .catch(this.handleError);
  }

  searchFoodDetails(id: number): Promise<FoodSearchDetailsResult> {
    return this._http.get(AppUris.SearchFoodDetails(id))
      .then((response: Response) => {
        return new FoodSearchDetailsResult(<IFoodSearchDetailsResult>response.json());
      })
      .catch(this.handleError);
  }
}
