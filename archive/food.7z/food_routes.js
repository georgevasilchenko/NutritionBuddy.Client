
  static FoodEdit: Route = <Route>{
    path: 'food/edit/:id',
    component: FoodEditComponent,
    canActivate: [AuthGuardService],
    data: {
      routeId: FoodRouteIds.FoodEdit,
      title: FoodRouteNames.FoodEdit,
      navigation: '/food/edit'
    },
  };
  static FoodCreate: Route = <Route>{
    path: 'food/edit',
    component: FoodEditComponent,
    canActivate: [AuthGuardService],
    data: {
      routeId: FoodRouteIds.FoodCreate,
      title: FoodRouteNames.FoodCreate,
      navigation: '/food/edit',
      model: {}
    },
  };
  static FoodCollection: Route = <Route>{
    path: 'food/select',
    component: FoodCollectionComponent,
    canActivate: [AuthGuardService],
    data: {
      routeId: FoodRouteIds.FoodCollection,
      title: FoodRouteNames.FoodCollection,
      navigation: '/food/select'
    },
  };
  static FoodSearch: Route = <Route>{
    path: 'food/search',
    component: FoodSearchComponent,
    canActivate: [AuthGuardService],
    data: {
      routeId: FoodRouteIds.FoodSearch,
      title: FoodRouteNames.FoodSearch,
      navigation: '/food/search'
    },
  };
